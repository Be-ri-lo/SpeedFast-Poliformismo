package org.speedFast.model;

public class PedidoComida extends Pedido {

    private String restaurante;
    private int cantidadPlatos;

    public PedidoComida(int idPedido, String direccionEntrega, double distanciaKm,
                        String restaurante, int cantidadPlatos) {
        super(idPedido, direccionEntrega, distanciaKm);
        this.restaurante = restaurante;
        setCantidadPlatos(cantidadPlatos);
    }

    // tiempo = 15 min + 2 min por km; +2 min por cada plato extra
    @Override
    public double calcularTiempoEntrega() {
        double tiempo = 15 + (2 * getDistanciaKm());
        if (cantidadPlatos > 1) {
            tiempo += (cantidadPlatos - 1) * 2;
        }
        return tiempo;
    }

    @Override
    public void asignarRepartidor() {
        confirmarAsignacion("Camila Soto (moto - alimentos)", "asignación automática");
    }

    @Override
    public void despachar() {
        super.despachar();
        registrarEvento("Comida de " + restaurante + " despachada en envase térmico");
    }

    @Override
    protected void mostrarDetalleEspecifico() {
        System.out.println("Restaurante: " + restaurante);
        System.out.println("Platos: " + cantidadPlatos);
    }

    public String getRestaurante() {
        return restaurante;
    }

    public int getCantidadPlatos() {
        return cantidadPlatos;
    }

    private void setCantidadPlatos(int cantidadPlatos) {
        if (cantidadPlatos < 1) {
            throw new IllegalArgumentException("El pedido de comida debe incluir al menos 1 plato");
        }
        this.cantidadPlatos = cantidadPlatos;
    }
}
