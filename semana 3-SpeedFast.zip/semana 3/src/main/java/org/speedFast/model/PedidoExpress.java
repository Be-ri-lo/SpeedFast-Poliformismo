package org.speedFast.model;

public class PedidoExpress extends Pedido {

    private String prioridad;

    public PedidoExpress(int idPedido, String direccionEntrega, double distanciaKm, String prioridad) {
        super(idPedido, direccionEntrega, distanciaKm);
        setPrioridad(prioridad);
    }

    // tiempo = 10 min base; +5 si distancia > 5 km; -2 si prioridad ALTA
    @Override
    public double calcularTiempoEntrega() {
        double tiempo = 10;
        if (getDistanciaKm() > 5) {
            tiempo += 5;
        }
        if ("ALTA".equals(prioridad)) {
            tiempo = Math.max(10, tiempo - 2);
        }
        return tiempo;
    }

    @Override
    public void asignarRepartidor() {
        String perfil = "ALTA".equals(prioridad)
                ? "Ana Torres (bici eléctrica - express prioritario)"
                : "Pedro Núñez (auto - express)";
        confirmarAsignacion(perfil, "asignación automática");
    }

    @Override
    public void despachar() {
        super.despachar();
        registrarEvento("Despacho express con prioridad " + prioridad);
    }

    @Override
    protected void mostrarDetalleEspecifico() {
        System.out.println("Prioridad: " + prioridad);
    }

    public String getPrioridad() {
        return prioridad;
    }

    private void setPrioridad(String prioridad) {
        if (prioridad == null || prioridad.isBlank()) {
            throw new IllegalArgumentException("La prioridad del envío express no puede estar vacía");
        }
        String valor = prioridad.trim().toUpperCase();
        if (!valor.equals("ALTA") && !valor.equals("NORMAL")) {
            throw new IllegalArgumentException("La prioridad express debe ser ALTA o NORMAL");
        }
        this.prioridad = valor;
    }
}
