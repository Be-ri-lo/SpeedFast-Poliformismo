package org.speedFast.model;

public class PedidoEncomienda extends Pedido {

    private double pesoKg;
    private boolean esFragil;

    public PedidoEncomienda(int idPedido, String direccionEntrega, double distanciaKm,
                            double pesoKg, boolean esFragil) {
        super(idPedido, direccionEntrega, distanciaKm);
        setPesoKg(pesoKg);
        this.esFragil = esFragil;
    }

    // tiempo = 20 min + 1.5 min por km (redondeado); +5 si peso > 10 kg; +3 si es frágil
    @Override
    public double calcularTiempoEntrega() {
        double tiempo = Math.round(20 + (1.5 * getDistanciaKm()));
        if (pesoKg > 10) {
            tiempo += 5;
        }
        if (esFragil) {
            tiempo += 3;
        }
        return tiempo;
    }

    @Override
    public void asignarRepartidor() {
        String perfil = esFragil
                ? "Diego Rivas (furgón - carga frágil)"
                : "Diego Rivas (furgón - encomiendas)";
        confirmarAsignacion(perfil, "asignación automática");
    }

    @Override
    public void despachar() {
        super.despachar();
        registrarEvento("Encomienda de " + pesoKg + " kg verificada y despachada"
                + (esFragil ? " con sello de frágil" : ""));
    }

    @Override
    protected void mostrarDetalleEspecifico() {
        System.out.println("Peso: " + pesoKg + " kg");
        System.out.println("Frágil: " + (esFragil ? "Sí" : "No"));
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public boolean isEsFragil() {
        return esFragil;
    }

    private void setPesoKg(double pesoKg) {
        if (pesoKg <= 0 || pesoKg > 50) {
            throw new IllegalArgumentException("El peso de la encomienda debe estar entre 0.1 y 50 kg");
        }
        this.pesoKg = pesoKg;
    }
}
